import { useEffect } from 'react';
import { motion } from 'motion/react';
import { useAppStore } from '../store/appStore';
import { Zap } from 'lucide-react';

export function SplashView() {
  const setView = useAppStore((state) => state.setView);

  useEffect(() => {
    const timer = setTimeout(() => {
      setView('welcome');
    }, 2500);
    return () => clearTimeout(timer);
  }, [setView]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.05 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="absolute inset-0 bg-zinc-950 flex flex-col items-center justify-center"
    >
      <div className="relative">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.8, 0.3],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute inset-0 bg-indigo-500/30 blur-3xl rounded-full"
        />
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative z-10 bg-zinc-900/50 p-6 rounded-3xl border border-white/5 backdrop-blur-xl"
        >
          <Zap className="w-12 h-12 text-indigo-400 fill-indigo-400/20" />
        </motion.div>
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        className="mt-8 text-center"
      >
        <h1 className="text-2xl font-medium tracking-tight text-white">Oxidity</h1>
        <p className="text-zinc-500 text-sm mt-1 tracking-wide uppercase font-medium">Private Execution</p>
      </motion.div>
    </motion.div>
  );
}
