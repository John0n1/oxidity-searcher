import { motion, AnimatePresence } from 'motion/react';
import { useAppStore } from '../store/appStore';
import { Home, Activity, ArrowLeftRight, BarChart3, Settings } from 'lucide-react';
import { cn } from '../utils/cn';

// Placeholders for tabs
import { HomeTab } from './main/HomeTab';
import { ActivityTab } from './main/ActivityTab';
import { SwapTab } from './main/SwapTab';
import { InsightsTab } from './main/InsightsTab';
import { SettingsTab } from './main/SettingsTab';

const TABS = [
  { id: 'home', icon: Home, label: 'Home' },
  { id: 'activity', icon: Activity, label: 'Activity' },
  { id: 'swap', icon: ArrowLeftRight, label: 'Swap' },
  { id: 'insights', icon: BarChart3, label: 'Insights' },
  { id: 'settings', icon: Settings, label: 'Settings' },
] as const;

export function MainView() {
  const currentTab = useAppStore((state) => state.currentTab);
  const setTab = useAppStore((state) => state.setTab);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      className="absolute inset-0 bg-zinc-950 flex flex-col"
    >
      <div className="flex-1 overflow-hidden relative">
        <AnimatePresence mode="wait">
          {currentTab === 'home' && <HomeTab key="home" />}
          {currentTab === 'activity' && <ActivityTab key="activity" />}
          {currentTab === 'swap' && <SwapTab key="swap" />}
          {currentTab === 'insights' && <InsightsTab key="insights" />}
          {currentTab === 'settings' && <SettingsTab key="settings" />}
        </AnimatePresence>
      </div>

      {/* Bottom Navigation */}
      <div className="h-20 bg-zinc-950 border-t border-white/5 flex items-center justify-around px-2 pb-safe">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setTab(tab.id as any)}
              className="flex flex-col items-center justify-center w-16 h-14 gap-1 relative"
            >
              {isActive && (
                <motion.div
                  layoutId="active-tab"
                  className="absolute -top-3 w-8 h-1 bg-indigo-500 rounded-b-full shadow-[0_0_10px_rgba(99,102,241,0.5)]"
                />
              )}
              <Icon
                className={cn(
                  "w-6 h-6 transition-colors duration-300",
                  isActive ? "text-white" : "text-zinc-500"
                )}
              />
              <span
                className={cn(
                  "text-[10px] font-medium transition-colors duration-300",
                  isActive ? "text-white" : "text-zinc-500"
                )}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </motion.div>
  );
}
