import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowDown, Settings2, ShieldCheck, Zap, Info, ChevronDown } from 'lucide-react';
import { cn } from '../../utils/cn';

export function SwapTab() {
  const [amountIn, setAmountIn] = useState('');
  const [amountOut, setAmountOut] = useState('');
  const [isReviewing, setIsReviewing] = useState(false);

  const handleSwap = () => {
    setIsReviewing(true);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.3 }}
      className="absolute inset-0 overflow-y-auto pb-24"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-6 pb-4 sticky top-0 bg-zinc-950/80 backdrop-blur-xl z-10 border-b border-white/5">
        <h2 className="text-2xl font-semibold tracking-tight">Swap</h2>
        <button className="w-10 h-10 bg-zinc-900 border border-white/5 rounded-full flex items-center justify-center hover:bg-zinc-800 transition-colors">
          <Settings2 className="w-5 h-5 text-zinc-400" />
        </button>
      </div>

      <div className="px-6 py-4">
        <AnimatePresence mode="wait">
          {!isReviewing ? (
            <motion.div
              key="input"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-2 relative"
            >
              {/* From Input */}
              <div className="bg-zinc-900 border border-white/5 rounded-3xl p-5 hover:border-white/10 transition-colors">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-zinc-500">You pay</span>
                  <span className="text-sm font-medium text-zinc-500">Balance: 0.00</span>
                </div>
                <div className="flex items-center justify-between gap-4">
                  <input
                    type="number"
                    placeholder="0"
                    value={amountIn}
                    onChange={(e) => setAmountIn(e.target.value)}
                    className="bg-transparent text-4xl font-semibold text-white placeholder:text-zinc-700 focus:outline-none w-full"
                  />
                  <button className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-700 transition-colors px-4 py-2 rounded-full shrink-0">
                    <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-xs font-bold">E</div>
                    <span className="font-semibold">ETH</span>
                    <ChevronDown className="w-4 h-4 text-zinc-400" />
                  </button>
                </div>
                <div className="text-sm text-zinc-500 mt-2">$0.00</div>
              </div>

              {/* Swap Button */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
                <button className="w-12 h-12 bg-zinc-950 border-[4px] border-zinc-950 rounded-2xl flex items-center justify-center hover:bg-zinc-800 transition-colors">
                  <ArrowDown className="w-5 h-5 text-zinc-400" />
                </button>
              </div>

              {/* To Input */}
              <div className="bg-zinc-900 border border-white/5 rounded-3xl p-5 hover:border-white/10 transition-colors">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-zinc-500">You receive</span>
                  <span className="text-sm font-medium text-zinc-500">Balance: 0.00</span>
                </div>
                <div className="flex items-center justify-between gap-4">
                  <input
                    type="number"
                    placeholder="0"
                    value={amountOut}
                    onChange={(e) => setAmountOut(e.target.value)}
                    className="bg-transparent text-4xl font-semibold text-white placeholder:text-zinc-700 focus:outline-none w-full"
                    readOnly
                  />
                  <button className="flex items-center gap-2 bg-indigo-500 hover:bg-indigo-600 transition-colors px-4 py-2 rounded-full shrink-0">
                    <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center text-xs font-bold text-indigo-500">$</div>
                    <span className="font-semibold">USDC</span>
                    <ChevronDown className="w-4 h-4 text-indigo-200" />
                  </button>
                </div>
                <div className="text-sm text-zinc-500 mt-2">$0.00</div>
              </div>

              {/* Execution Info */}
              <div className="mt-6 mb-8 bg-indigo-500/5 border border-indigo-500/10 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-indigo-400" />
                    <span className="font-medium text-indigo-100">Private Routing Active</span>
                  </div>
                  <Info className="w-4 h-4 text-indigo-400/50" />
                </div>
                <div className="flex items-center gap-2 text-sm text-indigo-300/70">
                  <Zap className="w-4 h-4" />
                  <span>Eligible for gas rebates on success</span>
                </div>
              </div>

              <button
                onClick={handleSwap}
                disabled={!amountIn}
                className="w-full bg-white text-black font-semibold py-4 rounded-2xl hover:bg-zinc-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Review Swap
              </button>
            </motion.div>
          ) : (
            <motion.div
              key="review"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-4"
            >
              <div className="text-center mb-8">
                <h3 className="text-xl font-semibold mb-2">Review Swap</h3>
                <p className="text-zinc-400">Confirm transaction details</p>
              </div>

              <div className="bg-zinc-900 border border-white/5 rounded-3xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center font-bold">E</div>
                    <div>
                      <div className="font-semibold text-lg">{amountIn || '0'} ETH</div>
                      <div className="text-sm text-zinc-500">~$0.00</div>
                    </div>
                  </div>
                  <ArrowDown className="w-5 h-5 text-zinc-500" />
                  <div className="flex items-center gap-3 text-right">
                    <div>
                      <div className="font-semibold text-lg">{amountOut || '0'} USDC</div>
                      <div className="text-sm text-zinc-500">~$0.00</div>
                    </div>
                    <div className="w-10 h-10 bg-white text-indigo-500 rounded-full flex items-center justify-center font-bold">$</div>
                  </div>
                </div>

                <div className="space-y-3 pt-6 border-t border-white/5">
                  <div className="flex justify-between text-sm">
                    <span className="text-zinc-400">Rate</span>
                    <span className="font-medium">1 ETH = 3,450 USDC</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-zinc-400">Network Fee</span>
                    <span className="font-medium text-zinc-300">~$4.50 (0.0013 ETH)</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-zinc-400">Execution Mode</span>
                    <span className="font-medium text-indigo-400 flex items-center gap-1">
                      <ShieldCheck className="w-4 h-4" /> Private
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-8">
                <button
                  onClick={() => setIsReviewing(false)}
                  className="flex-1 bg-zinc-900 text-white font-semibold py-4 rounded-2xl hover:bg-zinc-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  className="flex-[2] bg-indigo-500 text-white font-semibold py-4 rounded-2xl hover:bg-indigo-600 transition-colors shadow-[0_0_20px_rgba(99,102,241,0.3)]"
                >
                  Confirm Swap
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
