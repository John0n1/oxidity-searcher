import { motion } from 'motion/react';
import { Shield, KeyRound, Bell, Smartphone, Moon, HelpCircle, FileText, ChevronRight, Wallet, LogOut, Fingerprint } from 'lucide-react';
import { cn } from '../../utils/cn';
import { useAppStore } from '../../store/appStore';

export function SettingsTab() {
  const biometricsEnabled = useAppStore((state) => state.biometricsEnabled);
  const setBiometricsEnabled = useAppStore((state) => state.setBiometricsEnabled);
  const activeAccountId = useAppStore((state) => state.activeAccountId);
  const accounts = useAppStore((state) => state.accounts);
  const activeAccount = accounts.find(a => a.id === activeAccountId);

  const SECTIONS = [
    {
      title: 'Wallet',
      items: [
        { icon: Wallet, label: 'Manage Wallets', value: `${accounts.length} Wallet${accounts.length > 1 ? 's' : ''}` },
        { icon: Smartphone, label: 'Connected Apps', value: '0 Apps' },
      ]
    },
    {
      title: 'Security',
      items: [
        { icon: KeyRound, label: 'Recovery Phrase', value: '', warning: true },
        { icon: Shield, label: 'App Security', value: 'Passcode' },
        { 
          icon: Fingerprint, 
          label: 'Biometrics', 
          value: biometricsEnabled ? 'On' : 'Off',
          onClick: () => setBiometricsEnabled(!biometricsEnabled)
        },
      ]
    },
    {
      title: 'Preferences',
      items: [
        { icon: Bell, label: 'Notifications', value: 'On' },
        { icon: Moon, label: 'Theme', value: 'Dark' },
      ]
    },
    {
      title: 'About',
      items: [
        { icon: HelpCircle, label: 'Help & Support', value: '' },
        { icon: FileText, label: 'Legal & Privacy', value: '' },
      ]
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.3 }}
      className="absolute inset-0 overflow-y-auto pb-24"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-6 pb-4 sticky top-0 bg-zinc-950/80 backdrop-blur-xl z-10 border-b border-white/5">
        <h2 className="text-2xl font-semibold tracking-tight">Settings</h2>
      </div>

      <div className="px-6 py-4 space-y-8">
        {/* Profile / Wallet Summary */}
        <div className="flex items-center gap-4 bg-zinc-900 border border-white/5 rounded-3xl p-5">
          <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center border-2 border-zinc-950 shadow-lg" />
          <div className="flex-1">
            <h3 className="font-semibold text-lg mb-0.5">{activeAccount?.name || 'Main Wallet'}</h3>
            <p className="text-sm text-zinc-500 font-mono">{activeAccount?.address || '0x1234...5678'}</p>
          </div>
          <button className="bg-zinc-800 hover:bg-zinc-700 transition-colors px-4 py-2 rounded-full text-sm font-medium">
            Copy
          </button>
        </div>

        {/* Sections */}
        {SECTIONS.map((section, i) => (
          <div key={i}>
            <h4 className="text-sm font-medium text-zinc-500 uppercase tracking-wider mb-3 px-2">
              {section.title}
            </h4>
            <div className="bg-zinc-900 border border-white/5 rounded-3xl overflow-hidden">
              {section.items.map((item, j) => (
                <button
                  key={j}
                  onClick={item.onClick}
                  className={cn(
                    "w-full flex items-center justify-between p-4 hover:bg-zinc-800 transition-colors",
                    j !== section.items.length - 1 && "border-b border-white/5"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-8 h-8 rounded-xl flex items-center justify-center",
                      item.warning ? "bg-red-500/10" : "bg-zinc-800"
                    )}>
                      <item.icon className={cn(
                        "w-4 h-4",
                        item.warning ? "text-red-400" : "text-zinc-400"
                      )} />
                    </div>
                    <span className={cn(
                      "font-medium",
                      item.warning ? "text-red-400" : "text-white"
                    )}>
                      {item.label}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {item.value && (
                      <span className="text-sm text-zinc-500 font-medium">{item.value}</span>
                    )}
                    <ChevronRight className="w-4 h-4 text-zinc-600" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Lock Wallet */}
        <button 
          onClick={() => {
            useAppStore.getState().setIsLocked(true);
          }}
          className="w-full flex items-center justify-center gap-2 bg-zinc-900 border border-white/5 text-red-400 font-medium py-4 rounded-2xl hover:bg-red-500/10 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Lock Wallet
        </button>
      </div>
    </motion.div>
  );
}
