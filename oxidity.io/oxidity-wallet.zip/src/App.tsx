import { useEffect } from 'react';
import { useAppStore } from './store/appStore';
import { AnimatePresence, motion } from 'motion/react';
import { SplashView } from './views/SplashView';
import { WelcomeView } from './views/WelcomeView';
import { CreateWalletView } from './views/CreateWalletView';
import { ImportWalletView } from './views/ImportWalletView';
import { WalkthroughView } from './views/WalkthroughView';
import { MainView } from './views/MainView';
import { LockScreenView } from './views/LockScreenView';

export default function App() {
  const currentView = useAppStore((state) => state.currentView);
  const isLocked = useAppStore((state) => state.isLocked);

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center sm:p-4 font-sans selection:bg-indigo-500/30">
      <div className="w-full h-[100dvh] sm:h-[844px] sm:w-[390px] bg-zinc-950 sm:rounded-[40px] sm:border-[8px] border-zinc-900 overflow-hidden relative shadow-2xl shadow-indigo-500/10 no-scrollbar">
        <AnimatePresence mode="wait">
          {isLocked ? (
            <LockScreenView key="lock" />
          ) : (
            <>
              {currentView === 'splash' && <SplashView key="splash" />}
              {currentView === 'welcome' && <WelcomeView key="welcome" />}
              {currentView === 'create-wallet' && <CreateWalletView key="create" />}
              {currentView === 'import-wallet' && <ImportWalletView key="import" />}
              {currentView === 'walkthrough' && <WalkthroughView key="walk" />}
              {currentView === 'main' && <MainView key="main" />}
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
