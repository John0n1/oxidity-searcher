import { create } from 'zustand';

type View = 
  | 'splash'
  | 'welcome'
  | 'create-wallet'
  | 'import-wallet'
  | 'walkthrough'
  | 'main';

type MainTab = 'home' | 'activity' | 'swap' | 'insights' | 'settings';

export interface Account {
  id: string;
  name: string;
  address: string;
  balance: number;
  fiatBalance: number;
}

interface AppState {
  currentView: View;
  currentTab: MainTab;
  walletCreated: boolean;
  
  accounts: Account[];
  activeAccountId: string;
  
  biometricsEnabled: boolean;
  isLocked: boolean;

  setView: (view: View) => void;
  setTab: (tab: MainTab) => void;
  setWalletCreated: (created: boolean) => void;
  
  addAccount: (account: Omit<Account, 'id'>) => void;
  setActiveAccount: (id: string) => void;
  renameAccount: (id: string, name: string) => void;
  
  setBiometricsEnabled: (enabled: boolean) => void;
  setIsLocked: (locked: boolean) => void;
}

export const useAppStore = create<AppState>((set) => ({
  currentView: 'splash',
  currentTab: 'home',
  walletCreated: false,
  
  accounts: [
    {
      id: '1',
      name: 'Main Wallet',
      address: '0x1234...5678',
      balance: 0,
      fiatBalance: 0,
    }
  ],
  activeAccountId: '1',
  
  biometricsEnabled: false,
  isLocked: false,

  setView: (view) => set({ currentView: view }),
  setTab: (tab) => set({ currentTab: tab }),
  setWalletCreated: (created) => set({ walletCreated: created }),
  
  addAccount: (account) => set((state) => {
    const newAccount = { ...account, id: Math.random().toString(36).substring(7) };
    return {
      accounts: [...state.accounts, newAccount],
      activeAccountId: newAccount.id,
    };
  }),
  setActiveAccount: (id) => set({ activeAccountId: id }),
  renameAccount: (id, name) => set((state) => ({
    accounts: state.accounts.map(a => a.id === id ? { ...a, name } : a)
  })),
  
  setBiometricsEnabled: (enabled) => set({ biometricsEnabled: enabled }),
  setIsLocked: (locked) => set({ isLocked: locked }),
}));
