import{C as o,B as e}from"./vendor-native-CtdRN_tP.js";async function a(r){if(r){if(o.isNativePlatform()){await e.open({url:r});return}window.open(r,"_blank","noopener,noreferrer")}}export{a as o};
